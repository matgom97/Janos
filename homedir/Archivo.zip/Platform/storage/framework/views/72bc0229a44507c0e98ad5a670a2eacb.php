<sidebar class="invisible">

<a href="<?php echo $__env->yieldContent('link1'); ?>" style="text-decoration:none">
    <div class="side-item">
        <?php echo $__env->yieldContent('Icon1'); ?>
        <span class="item-accordion">
            <?php echo $__env->yieldContent('Item1'); ?>
        </span>
    </div>
</a>
   
<a href="<?php echo $__env->yieldContent('link2'); ?>" style="text-decoration:none">

    <div class="side-item">
        <?php echo $__env->yieldContent('Icon2'); ?>
        <span class="item-accordion">
            <?php echo $__env->yieldContent('Item2'); ?>
        </span>
    </div>
</a>

<a href="<?php echo $__env->yieldContent('link3'); ?>" style="text-decoration:none">

    <div class="side-item">
        <?php echo $__env->yieldContent('Icon3'); ?>
        <span class="item-accordion">
            <?php echo $__env->yieldContent('Item3'); ?>
        </span>
    </div>
</a>

<a href="<?php echo $__env->yieldContent('link4'); ?>" style="text-decoration:none">

    <div class="side-item">
        <?php echo $__env->yieldContent('Icon4'); ?>
        <span class="item-accordion">
            <?php echo $__env->yieldContent('Item4'); ?>
        </span>
    </div>
</a>
<a href="<?php echo $__env->yieldContent('link5'); ?>" style="text-decoration:none">

    <div class="side-item">
        <?php echo $__env->yieldContent('Icon5'); ?>
        <span class="item-accordion">
            <?php echo $__env->yieldContent('Item5'); ?>
        </span>
    </div>
</a>
    <?php echo $__env->yieldContent('side-item'); ?>


</sidebar>
<?php /**PATH /Users/imac008/Documents/BMJanosLaravel-main/resources/views/dashboard/components/sidebar.blade.php ENDPATH**/ ?>