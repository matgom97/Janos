<?php $__env->startSection('navadmin'); ?>
active
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-main">
        <a href="<?php echo $__env->yieldContent('LinkListade'); ?>" class="menu-list " style="text-decoration: none">
            <button class="item-button menu-list-1" style="margin-top: 20px">
                <?php echo $__env->yieldContent('Listade'); ?>
            </button>
        </a>
        <a href="<?php echo $__env->yieldContent('LinkCreacionde'); ?>" class="menu-list  " style="text-decoration: none">
        <button class="item-button menu-list-2" style="margin-top: 10px">
            <?php echo $__env->yieldContent('Creacionde'); ?>
        </button>
        </a>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('link1'); ?>
<?php echo e(route('admin.listausuarios')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('Icon1'); ?>
<i class='bx bx-user-circle'></i>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('Item1'); ?>
    Usuarios
<?php $__env->stopSection(); ?>


<?php $__env->startSection('link2'); ?>
<?php echo e(route('admin.listahoteles')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('Icon2'); ?>
<i class='bx bx-building-house' ></i>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('Item2'); ?>
    Hoteles
<?php $__env->stopSection(); ?>

<?php $__env->startSection('link3'); ?>
<?php echo e(route('admin.listapisos')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('Icon3'); ?>
<i class='bx bx-menu' ></i>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('Item3'); ?>
    Pisos
<?php $__env->stopSection(); ?>

<?php $__env->startSection('link4'); ?>
<?php echo e(route('admin.listahabitaciones')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('Icon4'); ?>
<i class='bx bx-home-alt-2' ></i>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('Item4'); ?>
    Habitaciones
<?php $__env->stopSection(); ?>

<?php $__env->startSection('link5'); ?>
<?php echo e(route('admin.listadispositivos')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('Icon5'); ?>
<i class='bx bx-devices' ></i>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('Item5'); ?>
    Dispositivos
<?php $__env->stopSection(); ?>


<?php $__env->startSection('section'); ?>
    <div class="section-main">
        <div class="section">
            <?php echo $__env->yieldContent('admin-content'); ?>


        </div>
    </div>
<?php $__env->stopSection(); ?>


<style scoped>
    :root {
        --primary-color: #F68B1C;
        --secondary-color: #17102d;
    }

    .menu-list:hover .item-button{
        color: #F68B1C !important;
        border-left:6px solid #F68B1C !important;
        border-right:1px solid #F68B1C !important;
        border-top:1px solid #F68B1C !important;
        border-bottom:1px solid #F68B1C !important;
    }

    .section {
        width: 99%;
        background: white;
        height: 98%;
        border-radius: 6px;
        padding-bottom: 0px !important;

    }

    .section-main {
        width: 100%;
        height: 98%;
        background-color: #efefef;
        display: flex;
        padding: 10px;
        justify-content: center;
    }

    .content-main {
        width: 98%;
        height: 98%;
        background-color: #efefef;
        padding: 10px 10px;
        
    }

    .item-button {
        font-size: 20px;
        width: 92%;
        color: #17102d;
        background-color: #ffffff;
        border: 1px solid #17102d;
        border-radius: 4px;
        padding: 10px;
        border-left: 6px solid #17102d;
        box-shadow: 1px 1px 9px #0003;
        display: flex;

    }
</style>

<?php echo $__env->make('dashboard.layouts.inicio', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/imac008/Documents/BMJanosLaravel-main/resources/views/dashboard/layouts/admin.blade.php ENDPATH**/ ?>