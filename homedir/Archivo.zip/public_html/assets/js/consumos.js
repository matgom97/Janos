const entityId1 = "sensor.home_energy_meter_gen5_electric_consumption_a";
const entityId2 = "sensor.home_energy_meter_gen5_electric_consumption_w_3";
const entityId3 = "sensor.home_energy_meter_gen5_electric_consumption_kwh";

const startDate = moment().subtract(7, "days").startOf("day").toISOString();
const endDate = moment().subtract(0, "days").startOf("day").toISOString();

/* const startDate = moment().subtract(7, 'days').startOf('day').toISOString();
const endDate = moment().endOf('day').toISOString();  */

/* const startDate = moment().subtract(3, 'weeks').startOf('week').toISOString();
const endDate = moment().subtract(3, 'weeks').endOf('week').toISOString(); */
//const accessToken = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJmMTE4Y2U5NmQwYjk0OGY0ODZkZWIwNmQwN2I1NzY3YiIsImlhdCI6MTY4NDM0MDA3NiwiZXhwIjoxOTk5NzAwMDc2fQ.Q_b8z5eFUa9eNb2kzMufqDKRpvPAV4aKePb_Zcu8_d8';

const baseUrl = "https://bmsjanos.duckdns.org/api";
const accessToken =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJhM2RhNGQ4YjE1NGI0ZjkxOTgwYmYxZTBmNTQwNTg5NSIsImlhdCI6MTY5ODIwMjk4MSwiZXhwIjoyMDEzNTYyOTgxfQ.ueg1XYgm1PsyJCIGltXNHZn3aWsAoKra2YoFXQzkuL8";

const url1 = `https://bmsjanos.duckdns.org/api/history/period/${startDate}?end_time=${endDate}&filter_entity_id=${entityId1}`;
const url2 = `https://bmsjanos.duckdns.org/api/history/period/${startDate}?end_time=${endDate}&filter_entity_id=${entityId2}`;
const url3 = `https://bmsjanos.duckdns.org/api/history/period/${startDate}?end_time=${endDate}&filter_entity_id=${entityId3}`;

const options = {
  method: "GET",
  headers: {
    Authorization: `Bearer ${accessToken}`,
  },
};



Promise.all([fetch(url1, options), fetch(url2, options), fetch(url3, options)])
  .then((responses) =>
    Promise.all(responses.map((response) => response.json()))
  )
  .then((data) => {
    const consumptionData1 = data[0][0];
    const consumptionData2 = data[1][0];
    const temperatureData = data[2][0];

    const labels = Array.from(
      new Set(
        consumptionData1.map((item) =>
          moment(item.last_changed).format("MMM D")
        )
      )
    );
    const labelstv = Array.from(
      new Set(
        consumptionData2.map((item) =>
          moment(item.last_changed).format("MMM D")
        )
      )
    );
    const labelstemperature = Array.from(
      new Set(
        temperatureData.map((item) => moment(item.last_changed).format("MMM D"))
      )
    );

    const values1 = consumptionData1.map((item) => item.state);

    const groupedvalues1 = consumptionData1.reduce((acc, item) => {
      const date = moment(item.last_changed).format("MMM D");
      if (!acc[date]) {
        acc[date] = [];
      }
      acc[date].push(parseFloat(item.state));
      return acc;
    }, {});
    
    const gvalues1 = Object.values(groupedvalues1).map(
      (values) => {
        const sum = values.reduce((a, b) => a + b, 0);
        return sum / values.length;
      }
    );


    const values2 = consumptionData2.map(item => item.state);



    const groupedvalues2 = consumptionData2.reduce((acc, item) => {
      const date = moment(item.last_changed).format("MMM D");
      if (!acc[date]) {
        acc[date] = [];
      }
      acc[date].push(parseFloat(item.state));
      return acc;
    }, {});
    
    const gvalues2 = Object.values(groupedvalues2).map(
      (values) => {
        const sum = values.reduce((a, b) => a + b, 0);
        return sum / values.length;
      }
    );
    const values3 = temperatureData.map((item) => item.state);

    // Agrupa los datos por día y calcula la suma total
    const groupedTemperatureData = temperatureData.reduce((acc, item) => {
      const date = moment(item.last_changed).format("MMM D");
      if (!acc[date]) {
        acc[date] = 0;
      }
      acc[date] += parseFloat(item.state);
      return acc;
    }, {});

    // Obtiene la suma total para cada día
    const temperatureValues = Object.values(groupedTemperatureData);


    /* Codigo para consultar que el numero de dias concuerda con el numero de datos */
    console.log("Dias de AIRE para graficar:", labels.length);
    console.log("Cantidad de valores de AIRE:", gvalues1.length);
    console.log('datos del aire', values3);
    console.log('datos del aire', values3.length);
    /*  */
    console.log("Dias de TEMPERATURA para graficar:", labels.length);
    console.log(
      "Cantidad de valores de TEMPERATURA:",
      temperatureValues.length
    );
    /*  */
    console.log("Dias de TV para graficar", labelstv.length);
    console.log("Cantidad de valores de TV:", gvalues2.length);

    console.log(gvalues2);

    /* Codigo que verifica que hayan suficientes datos para mostrar una grafica */

    if (
      values1.length === 0 ||
      values2.length === 0 ||
      temperatureValues.length === 0
    ) {
      console.log("No hay suficientes datos para mostrar las gráficas.");
    } else {

      
      // Aquí va el código para crear las gráficas
      const ctx1 = document.getElementById("powerConsumptionChart1");
      const consumptionChart1 = new Chart(ctx1, {
        type: "bar", // Cambiar el tipo de gráfico a 'bar' para gráficas de barras
        data: {
          labels: labels,
          datasets: [
            {
              label: "Consumo eléctrico Aire Acondicionado (kWh)",
              backgroundColor: "#F68B1C",
              borderColor: "#F68B1C",
              data: gvalues1,
              fill: false,
            },
          ],
        },
        options: {
          responsive: true,
          scales: {
            y: {
              beginAtZero: true,
            },
          },
        },
      });

      const labelstv = Object.keys(groupedvalues2);

      const ctx2 = document.getElementById("powerConsumptionChart2");
      const consumptionChart2 = new Chart(ctx2, {
        type: "bar", // Cambiar el tipo de gráfico a 'bar' para gráficas de barras
        data: {
          labels: labelstv,
          datasets: [
            {
              label: "Consumo eléctrico TV (kWh)",
              backgroundColor: "rgb(54, 162, 235)",
              borderColor: "rgb(54, 162, 235)",
              data: gvalues2,
              fill: false,
            },
          ],
        },
        options: {
          responsive: true,
          scales: {
            y: {
              beginAtZero: true,
            },
          },
        },
      });

      const labelstemperature = Object.keys(groupedTemperatureData);
      const ctx3 = document.getElementById("graficatemperatura");
      const temperatureChart = new Chart(ctx3, {
        type: "bar", // Cambiar el tipo de gráfico a 'bar' para gráficas de barras
        data: {
          labels: labelstemperature,
          datasets: [
            {
              label: "Temperatura",
              backgroundColor: "rgb(75, 192, 192)",
              borderColor: "rgb(75, 192, 192)",
              data: temperatureValues,
              fill: false,
            },
          ],
        },
        options: {
          responsive: true,
          scales: {
            y: {
              beginAtZero: true,
            },
          },
        },
      });
    }
  })
  .catch((error) => {
    console.error("Error al realizar la solicitud a la API:", error);
  });
