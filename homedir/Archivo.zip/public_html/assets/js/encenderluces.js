document.addEventListener("DOMContentLoaded", async function () {
  const baseUrl = 'https://bmsjanos.duckdns.org/api';
  const accessToken = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJhM2RhNGQ4YjE1NGI0ZjkxOTgwYmYxZTBmNTQwNTg5NSIsImlhdCI6MTY5ODIwMjk4MSwiZXhwIjoyMDEzNTYyOTgxfQ.ueg1XYgm1PsyJCIGltXNHZn3aWsAoKra2YoFXQzkuL8'; // Tu token aquí
  const interruptor1 = { id: '204-checkSwitch-1', entityId: 'switch.node_23' }; /* Luz habitacion 204 */
  const interruptor2 = { id: '204-checkSwitch-2', entityId: 'switch.node_19' }; /* Luz baño 204*/
  const interruptor3 = { id: '204-checkSwitch-3', entityId: 'switch.node_34' }; /* Luz 2 corredor */
  /* Contacto tv 203?*/
  const interruptor5 = { id: '204-checkSwitch-5', entityId: 'climate.ac_master' }; /* Aire acondicionado*/
  const interruptor6 = { id: '204-checkSwitch-6', entityId: 'switch.node_34_2' }; /*corredor 1 */
  const interruptor7 = { id: '204-checkSwitch-7', entityId: 'binary_sensor.node_41_motion_detection' }; /* Sensor*/

  
  const obtenerEstadoInterruptor = async (entityId) => {
    try {
      const response = await fetch(`${baseUrl}/states/${entityId}`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        },
      });
      const result = await response.json();
      const state = result.state;
      console.log(`Estado de entidad ${entityId}: ${state}`);
      return state;
    } catch (error) {
      console.error(`Error obteniendo estado de entidad ${entityId}: ${error}`);
    }
  };



  const encenderEntidad = async (entityId) => {
    try {
      const response = await fetch(`${baseUrl}/services/homeassistant/turn_on`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ entity_id: entityId })
      });
      const result = await response.json();
      console.log(`Entidad ${entityId} encendida`);
      return result;
    } catch (error) {
      console.error(`Error encendiendo entidad ${entityId}: ${error}`);
    }
  };

  const setHvacMode = async (entityId, mode) => {
    try {
      const response = await fetch(`${baseUrl}/services/climate/set_hvac_mode`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          entity_id: entityId,
          hvac_mode: mode
        })
      });
      const result = await response.json();
      console.log(`Modo HVAC de la entidad ${entityId} configurado en ${mode}`);
      return result;
    } catch (error) {
      console.error(`Error configurando el modo HVAC de la entidad ${entityId} en ${mode}: ${error}`);

    }
  };
  const apagarEntidad = async (entityId) => {
    try {
      const response = await fetch(`${baseUrl}/services/homeassistant/turn_off`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ entity_id: entityId })
      });
      const result = await response.json();
      console.log(`Entidad ${entityId} apagada`);
      return result;
    } catch (error) {
      console.error(`Error apagando entidad ${entityId}: ${error}`);
    }
  };
  

/*   const cambiarEstadoEntidad = async (entityId, newState) => {
    try {
      const response = await fetch(`${baseUrl}/states/${entityId}`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ state: newState })
      });
      const result = await response.json();
      console.log(`Entidad ${entityId} cambiada a estado ${newState}`);
      return result;
    } catch (error) {
      console.error(`Error cambiando estado de entidad ${entityId}: ${error}`);
    }
  }; */

  const actualizarEstadoInterruptor = async () => {
    try {
    
      const estadoInterruptor1 = await obtenerEstadoInterruptor(interruptor1.entityId);
      const estadoInterruptor2 = await obtenerEstadoInterruptor(interruptor2.entityId);
      const estadoInterruptor3 = await obtenerEstadoInterruptor(interruptor3.entityId);
     
      const estadoInterruptor5 = await obtenerEstadoInterruptor(interruptor5.entityId);
      const estadoInterruptor6 = await obtenerEstadoInterruptor(interruptor6.entityId);
      const estadoInterruptor7 = await obtenerEstadoInterruptor(interruptor7.entityId);

      const interruptorCheckbox1 = document.getElementById(interruptor1.id);
      const interruptorElement1 = document.getElementById(interruptor1.id);
      const selectInterruptor1 = document.getElementById(interruptor1.id);

      const interruptorCheckbox2 = document.getElementById(interruptor2.id);
      const interruptorElement2 = document.getElementById(interruptor2.id);
      const interruptorCheckbox3 = document.getElementById(interruptor3.id);
      const interruptorElement3 = document.getElementById(interruptor3.id);

      const interruptorCheckbox5 = document.getElementById(interruptor5.id);
      const interruptorElement5 = document.getElementById(interruptor5.id);
      const interruptorCheckbox6 = document.getElementById(interruptor6.id);
      const interruptorElement6 = document.getElementById(interruptor6.id);
      const interruptorCheckbox7 = document.getElementById(interruptor7.id);
      const interruptorElement7 = document.getElementById(interruptor7.id);

      if (estadoInterruptor1 === 'on') {
        interruptorCheckbox1.checked = true;
        selectInterruptor1.value = 0;
        interruptorElement1.classList.add('encendido');
        interruptorElement1.classList.remove('apagado');
      } else {
        interruptorCheckbox1.checked = false;
        interruptorElement1.classList.add('apagado');
        selectInterruptor1.value = 1;
        interruptorElement1.classList.remove('encendido');
      }

      if (estadoInterruptor2 === 'on') {
        interruptorCheckbox2.checked = true;
        interruptorElement2.classList.add('encendido');
        interruptorElement2.classList.remove('apagado');
      } else {
        interruptorCheckbox2.checked = false;
        interruptorElement2.classList.add('apagado');
        interruptorElement2.classList.remove('encendido');
      }

      if (estadoInterruptor3 === 'on') {
        interruptorCheckbox3.checked = true;
        interruptorElement3.classList.add('encendido');
        interruptorElement3.classList.remove('apagado');
      } else {
        interruptorCheckbox3.checked = false;
        interruptorElement3.classList.add('apagado');
        interruptorElement3.classList.remove('encendido');
      }


      if (estadoInterruptor5 === 'heat_cool') {
        interruptorCheckbox5.checked = true;
        interruptorElement5.classList.add('encendido');
        interruptorElement5.classList.remove('apagado');
      } else {
        interruptorCheckbox5.checked = false;
        interruptorElement5.classList.add('apagado');
        interruptorElement5.classList.remove('encendido');
      }

      if (estadoInterruptor6 === 'on') {
        interruptorCheckbox6.checked = true;
        interruptorElement6.classList.add('encendido');
        interruptorElement6.classList.remove('apagado');
      } else {
        interruptorCheckbox6.checked = false;
        interruptorElement6.classList.add('apagado');
        interruptorElement6.classList.remove('encendido');
      }

      if (estadoInterruptor7 === 'on') {
        interruptorCheckbox7.checked = true;
        interruptorElement7.classList.add('encendido');
        interruptorElement7.classList.remove('apagado');
      } else {
        interruptorCheckbox7.checked = false;
        interruptorElement7.classList.add('apagado');
        interruptorElement7.classList.remove('encendido');
      }
    } catch (error) {
      console.error(`Error actualizando estado de los interruptores: ${error}`);
    }
  };

  // Agregar un evento 'change' para el interruptor1
// Agregar un evento 'change' para el interruptor1
function agregarEventoCambio(interruptor) {
  const interruptorCheckbox = document.getElementById(interruptor.id);

  interruptorCheckbox.addEventListener('change', async () => {
    if (interruptorCheckbox.checked) {
      if (interruptor.id === 'interruptor5') {
        await setHvacMode(interruptor.entityId, 'cool'); // Utiliza la función setHvacMode
        console.log(`Aire acondicionado ${interruptor.id} configurado en modo cool`);
      } else {
        await encenderEntidad(interruptor.entityId); // Utiliza la función encenderEntidad
        console.log(`Switch ${interruptor.id} encendido`);
      }
    } else {
      if (interruptor.id === 'interruptor5') {
        await setHvacMode(interruptor.entityId, 'off'); // Utiliza la función setHvacMode
        console.log(`Aire acondicionado ${interruptor.id} apagado`);
      } else {
        await apagarEntidad(interruptor.entityId); // Utiliza la función apagarEntidad
        console.log(`Switch ${interruptor.id} apagado`);
      }
    }
  });
}

// Obtén una referencia al interruptor7
/* const interruptorCheckbox7 = document.getElementById(interruptor7.id);

// Agrega un controlador de eventos 'change' al interruptor7
interruptorCheckbox7.addEventListener('change', async () => {
  // Verifica si el interruptor7 está en 'on'
  if (interruptorCheckbox7.checked) {
    // Si el interruptor7 está en 'on', enciende el interruptor1
    await encenderEntidad(interruptor1.entityId);
    console.log('El interruptor1 ha sido encendido porque el interruptor7 está en on');
  }
}); */


  agregarEventoCambio(interruptor1);
  agregarEventoCambio(interruptor2);
  agregarEventoCambio(interruptor3);
  
  agregarEventoCambio(interruptor5);
  agregarEventoCambio(interruptor6);
  agregarEventoCambio(interruptor7);

  // Llama a la función para actualizar el estado de los interruptores
  actualizarEstadoInterruptor();
  setInterval(actualizarEstadoInterruptor, 3000);

  const obtenerTemperatura = async (entityId) => {
    try {
      const response = await fetch(`${baseUrl}/states/${entityId}`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        },
      });
      const result = await response.json();
      const temperature = result.state;
  
      // Get the HTML element
      const temperaturaElement = document.getElementById('temperatura_device');
      const temperaturaElement2 = document.getElementById('marker05');
  
      // Update the text content of the HTML element
      temperaturaElement.textContent = `Temperatura: ${temperature}`;
      temperaturaElement2.textContent = `${temperature}`;
  
      console.log(`La temperatura actual del dispositivo ${entityId} es: ${temperature}`);
      return temperature;
    } catch (error) {
      console.error(`Error obteniendo la temperatura del dispositivo ${entityId}: ${error}`);
    }
  };
  
  // Use the function
  obtenerTemperatura('sensor.ac_master_air_temperature');
  

});
