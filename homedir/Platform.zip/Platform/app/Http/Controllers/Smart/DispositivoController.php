<?php

namespace App\Http\Controllers\Smart;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use App\Models\Dispositivo;
use App\Models\Hotel;
use App\Models\Habitacion;
use Illuminate\Support\Facades\Auth;


class DispositivoController extends Controller
{
    //
    public function storeview() {
        $nombre = Auth::check() ? Auth::user()->name : "Usuario no autenticado";
        $hotelId = Auth::user()->user_hotel;
        $hotel = Hotel::with('pisos.habitaciones')->findOrFail($hotelId);
        $pisos = $hotel->pisos;
    
        // Obtener todas las habitaciones del hotel y convertirlas en una colección de modelos
        $habitaciones = collect();
        foreach ($pisos as $piso) {
            $habitaciones = $habitaciones->concat($piso->habitaciones);
        }
    
        return view('dashboard.admin.CreateDispositivos', compact('pisos', 'nombre', 'habitaciones'));
    }

    public function cargarHabitaciones($pisoId)
{
    $habitaciones = Habitacion::where('habitacion_piso_id', $pisoId)->get();
    
    return response()->json($habitaciones);
}


    public function showDispositivo()
    {
        $nombre = Auth::check() ? Auth::user()->name : "Usuario no autenticado";
        $hotelId = Auth::user()->user_hotel;
    
        $hotel = Hotel::findOrFail($hotelId);
    
        if (!$hotel) {
            // Manejo de error si no se encuentra el hotel
            return abort(404);
        }
    
        $dispositivos = [];
    
        foreach ($hotel->pisos as $piso) {
            foreach ($piso->habitaciones as $habitacion) {
                foreach ($habitacion->dispositivos as $dispositivo) {
                    $dispositivos[] = $dispositivo;
                }
            }
        }
    
        if (empty($dispositivos)) {
            $mensaje = "No hay dispositivos disponibles en este hotel en este momento.";
            return view('dashboard.admin.ListaDispositivos', compact('nombre', 'mensaje', 'dispositivos'));
        }
    
        return view('dashboard.admin.ListaDispositivos', compact('nombre', 'dispositivos'));
    }
    
    public function store (Request $request){
        try {
            $habitacion = new Habitacion;

            $habitacion->habitacion_nombre = $request->habitacion_nombre;
            $habitacion->habitacion_piso_id = $request->habitacion_piso_id;

            $habitacion->habitacion_descripcion = $request->habitacion_descripcion;
            $habitacion->habitacion_ocupacion = $request->habitacion_ocupacion;
            $habitacion->habitacion_estado = '1';
    
            $habitacion->modified_by = Auth::user()->id;
            if ($habitacion->save()) {
                Session::flash('success', 'Habitacion creada exitosamente');
            } else {
                Session::flash('error', 'La habitacion no se ha podido crear con éxito, por favor intenta nuevamente');
            }
        } catch (\Exception $e) {
            Session::flash('error', 'Error al crear la habitacion: ' . $e->getMessage());
        }
        return redirect()->back();
    }
}
