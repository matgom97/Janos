<nav>
    <div style="display: flex;">
        <div class="nav-item invisible-button addd" onclick="openNav()">
            <i class='bx bx-menu'></i>
        </div>
        <a style="text-decoration:none" href="<?php echo e(route('smart')); ?>">
        <div class="nav-item <?php echo $__env->yieldContent('navsmart'); ?>">
            <i class="bx bx-layer"> </i>
            Smart
        </div>
        </a>
        <div class="nav-item <?php echo $__env->yieldContent('navdata'); ?>">
            <i class='bx bx-data'></i>
            Data
        </div>

        <a style="text-decoration:none" href="<?php echo e(route('admin.listausuarios')); ?>">
            <div class="nav-item <?php echo $__env->yieldContent('navadmin'); ?>">
                <i class="bx bx-extension"></i>
                Admin
            </div>
        </a>
        <?php echo $__env->yieldContent('navbar-item'); ?>
    </div>
    <div class="dropdown">
        <div class="user-div" id="dropdown-button1">
            <?php echo $__env->yieldContent('user-name'); ?>
            <span>
                <?php echo e($nombre); ?>

            </span>
            <div class="user-photo" id="dropdown-button2">
                <?php echo $__env->yieldContent('user-acronym'); ?>
    <?php echo e(strtoupper(substr($nombre, 0, 1))); ?>

            </div>
        </div>
        <div class="dropdown-content" id="dropdown-content">
            <?php if(Auth::check()): ?>
                <a href="<?php echo e(route('profile.edit')); ?>"> <i style="font-size:20px" class='bx bx-user-circle'></i>
                    <span class="profile-settings">
                        Mi perfil
                    </span>
                </a>
            <?php else: ?>
                <a href="#"> <i style="font-size:20px" class='bx bx-user-circle'></i>
                    <span class="profile-settings">
                        Mi perfil
                    </span>
                </a>
            <?php endif; ?>

            <a href="#"><i style="font-size:20px" class='bx bx-cog'></i>
                <span class="profile-settings">Configuracion</span>
            </a>

            <?php if(Auth::check()): ?>
                <form style="padding: 12px;
                margin: 0px;
                    border-radius:5px"
                    class="close-sesion" action="<?php echo e(route('logout')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <button
                        style="    color: white;
                background: transparent;
                border: none;
                font-size: 16px;
                display: flex;"
                        class="" type="submit"><i style="font-size:20px" class='bx bx-exit'></i>
                        <span class="profile-settings">
                            Cerrar sesion
                        </span>
                    </button>

                </form>
            <?php else: ?>
                <a class="close-sesion" href="<?php echo e(route('welcome')); ?>"><i style="font-size:20px" class='bx bx-exit'></i>
                    <span class="profile-settings">
                        Cerrar sesion
                    </span>
                </a>
            <?php endif; ?>
        </div>
    </div>


</nav>
<?php /**PATH C:\Users\RYZEN\Documents\GitHub\BemsJanos-Main\resources\views/dashboard/components/navbar.blade.php ENDPATH**/ ?>